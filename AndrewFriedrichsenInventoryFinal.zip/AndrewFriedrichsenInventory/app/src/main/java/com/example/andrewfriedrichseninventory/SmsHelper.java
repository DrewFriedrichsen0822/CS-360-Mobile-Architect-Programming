package com.example.andrewfriedrichseninventory;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsHelper {

    public static final int REQ_SMS_PERMISSION = 3001;

    // Request SMS permission at runtime
    public static void requestSmsPermission(Activity activity) {
        if (ContextCompat.checkSelfPermission(activity, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(
                    activity,
                    new String[]{Manifest.permission.SEND_SMS},
                    REQ_SMS_PERMISSION
            );
        }
    }

    // Send SMS only if permission is granted
    public static void sendSms(Activity activity, String phoneNumber, String message) {
        if (ContextCompat.checkSelfPermission(activity, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {

            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phoneNumber, null, message, null, null);
                Toast.makeText(activity, "SMS alert sent", Toast.LENGTH_SHORT).show();

            } catch (Exception e) {
                Toast.makeText(activity, "Failed to send SMS", Toast.LENGTH_SHORT).show();
            }

        } else {
            Toast.makeText(activity, "SMS permission not granted", Toast.LENGTH_SHORT).show();
        }
    }
}
