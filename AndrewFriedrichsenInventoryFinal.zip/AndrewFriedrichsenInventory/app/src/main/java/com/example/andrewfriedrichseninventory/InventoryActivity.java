package com.example.andrewfriedrichseninventory;

import android.database.Cursor;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class InventoryActivity extends AppCompatActivity {

    private EditText etNewItemName, etNewItemQty;
    private Button btnAddItem;
    private ListView lvInventory;

    private DBHelper dbHelper;
    private SimpleCursorAdapter adapter;
    private Cursor cursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        dbHelper = new DBHelper(this);

        etNewItemName = findViewById(R.id.etNewItemName);
        etNewItemQty = findViewById(R.id.etNewItemQty);
        btnAddItem = findViewById(R.id.btnAddItem);
        lvInventory = findViewById(R.id.lvInventory);

        setupList();

        btnAddItem.setOnClickListener(v -> addItem());

        lvInventory.setOnItemLongClickListener((parent, view, position, id) -> {
            dbHelper.deleteItem(id);
            refreshList();
            Toast.makeText(this, "Item deleted", Toast.LENGTH_SHORT).show();
            return true;
        });

        lvInventory.setOnItemClickListener((parent, view, position, id) -> {
            Cursor c = (Cursor) adapter.getItem(position);
            String name = c.getString(c.getColumnIndexOrThrow(DBHelper.COL_ITEM_NAME));
            int qty = c.getInt(c.getColumnIndexOrThrow(DBHelper.COL_ITEM_QTY));
            String desc = c.getString(c.getColumnIndexOrThrow(DBHelper.COL_ITEM_DESC));

            dbHelper.updateItem(id, name, qty + 1, desc);
            refreshList();
            Toast.makeText(this, "Quantity updated", Toast.LENGTH_SHORT).show();
        });
    }

    private void setupList() {
        cursor = dbHelper.getAllItems();

        String[] from = { DBHelper.COL_ITEM_NAME, DBHelper.COL_ITEM_QTY };
        int[] to = { android.R.id.text1, android.R.id.text2 };

        adapter = new SimpleCursorAdapter(
                this,
                android.R.layout.simple_list_item_2,
                cursor,
                from,
                to,
                0
        );

        lvInventory.setAdapter(adapter);
    }

    private void refreshList() {
        Cursor newCursor = dbHelper.getAllItems();
        adapter.changeCursor(newCursor);
        cursor = newCursor;
    }

    private void addItem() {
        String name = etNewItemName.getText().toString().trim();
        String qtyStr = etNewItemQty.getText().toString().trim();

        if (TextUtils.isEmpty(name) || TextUtils.isEmpty(qtyStr)) {
            Toast.makeText(this, "Enter item name and quantity", Toast.LENGTH_SHORT).show();
            return;
        }

        int qty = Integer.parseInt(qtyStr);
        dbHelper.addItem(name, qty, "");

        refreshList();
        etNewItemName.setText("");
        etNewItemQty.setText("");
    }
}
