package com.example.andrewfriedrichseninventory;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsPermissionActivity extends AppCompatActivity {

    private TextView tvPermissionStatus;
    private Button btnRequestSmsPermission;

    private static final int REQ_SMS = 2001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);

        tvPermissionStatus = findViewById(R.id.tvPermissionStatus);
        btnRequestSmsPermission = findViewById(R.id.btnRequestSmsPermission);

        updateStatus();

        btnRequestSmsPermission.setOnClickListener(v -> requestSmsPermission());
    }

    private void updateStatus() {
        boolean granted = ContextCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;

        if (granted) {
            tvPermissionStatus.setText("SMS permission status: Granted");
            tvPermissionStatus.setTextColor(getColor(android.R.color.holo_green_dark));
        } else {
            tvPermissionStatus.setText("SMS permission status: Not granted");
            tvPermissionStatus.setTextColor(getColor(android.R.color.holo_red_dark));
        }
    }

    private void requestSmsPermission() {
        ActivityCompat.requestPermissions(
                this,
                new String[]{Manifest.permission.SEND_SMS},
                REQ_SMS
        );
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);

        if (requestCode == REQ_SMS) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Permission denied. App will continue without SMS alerts.", Toast.LENGTH_LONG).show();
            }
            updateStatus();
        }
    }
}
